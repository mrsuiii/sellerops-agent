# SellerOps Agent

Portfolio project for building and evaluating a small seller-assistance agent:

```text
deterministic simulator
    → frozen evaluation tasks
    → base-model evaluation
    → LoRA SFT
    → LangGraph runtime and trajectory replay
    → optional targeted DPO after preference-failure analysis
```

The project currently contains strict action schemas, a deterministic local
catalog/inventory/policy environment, an oracle task generator, disjoint
train/development/frozen-test splits, and model-independent SFT decision
records.

## Repository layout

```text
projects/sellerops-agent/
├── PLAN.md
├── data/
├── notebooks/
├── scripts/
├── src/sellerops/
└── tests/
```

The shared Conda environment remains at the learning-lab root. Activate it with:

```bash
conda activate llm-post-training
```

From this project directory, regenerate the deterministic dataset with:

```bash
conda run -n llm-post-training python scripts/generate_sellerops_dataset.py
```

Run the current tests with:

```bash
conda run -n llm-post-training pytest -q
```

See [PLAN.md](PLAN.md) for the step-by-step learning contract and current
milestone. The project-level plan is governed by the lab-level
[`TARGET.md`](../../TARGET.md).


## Guided full SFT on a cloud GPU

`notebooks/sft.ipynb` now provides a full-parameter SFT learning exercise for
Qwen2.5-0.5B-Instruct, with four exercises and notes before every code cell.
It includes target-only label masking, strict development evaluation, a two-step
smoke test, fresh-weight training, and saved-checkpoint evaluation.

Colab uses its managed Python runtime, as authorized on September 6. Run notebook
sections 1 and 1b to audit the GPU and install the pinned training libraries while
preserving the installed CUDA PyTorch build. Restart the Python session after an
installation, then continue. Requirements are in `configs/requirements.colab.txt`.
Local work still uses Conda `llm-post-training`; `configs/environment.cuda.yml`
remains optional for other CUDA hosts. The root environment.yml is unchanged.
Edit upload/output paths before execution. The Colab editor's notebook and the
notebook extracted from the ZIP are separate copies; save your editor copy to Drive.
The notebook intentionally stops at unfinished exercises.

The September 6 training choice is **full SFT**, superseding the earlier LoRA-only
training plan for this experiment. Episode-level replay and frozen evaluation
remain separate unfinished milestones. No SFT result has been produced yet.
